package com.company;

import java.util.HashMap;
import java.util.Scanner;

public class Game {
    private Room currentRoom;
    private HashMap<String, Handler> handlers = new HashMap<String, Handler>();
    public int blood = 50;
    public Scanner in = new Scanner(System.in);

    public Game() {
        handlers.put("go", new HandlerGo(this));
        handlers.put("bye", new HandlerBye(this));
        handlers.put("help", new HandlerHelp(this));
        createRooms();
    }

    private void createRooms() {
        Room outside, lobby, pub, study, grass, bedroom;

        //创建房间
        outside = new Room("城堡外");
        lobby = new Room("大堂");
        pub = new Room("小酒吧");
        study = new Room("书房");
        grass = new Room("草场");
        bedroom = new Room("卧室");

        //初始化房间入口
        outside.setExit("east", lobby);

        lobby.setExit("north", pub);
        lobby.setExit("west", outside);
        lobby.setExit("east", study);

        pub.setExit("south", lobby);
        pub.setExit("east", grass);

        study.setExit("north", grass);
        study.setExit("west", lobby);

        grass.setExit("north", bedroom);
        grass.setExit("south", study);
        grass.setExit( "west", pub );

        bedroom.setExit("south", grass);

        currentRoom = outside;//从城堡门外开始
    }

    private void printWelcome() {
        System.out.println();
        System.out.println("欢迎来到城堡！");
        System.out.println("这是一个超级无聊的游戏。");
        System.out.println("如果需要帮助，请输入 'help' 。");
        System.out.println();
        showPrompt();
    }


    //以下为用户命令
    public void goRoom(String direction) {
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            System.out.println("那里没有门！");
        } else {
            System.out.println("前往的路上遇到了怪物，将消耗"+nextRoom.hurt+"点血量，是否继续前往？（go-继续，q-不前往）");
            String tmp = in.next();
            if( tmp.equals("go")) {
                currentRoom = nextRoom;
                blood -= nextRoom.hurt;
                showPrompt();
            } else {
                System.out.println("已返回之前位置");
            }

        }
    }

    public void showPrompt() {
        System.out.println("你在" + currentRoom);
        if( blood > 0 ) {
            System.out.println("当前血量："+blood);
            System.out.print("出口有: ");
            System.out.print(currentRoom.getExitDesc());
            System.out.println();
        } else {
            System.out.println("在刚才的打斗中，你已牺牲，游戏结束");
            System.exit(0);
        }

    }

    public void play() {
        while (true) {
            String line = in.nextLine();
            String[] words = line.split(" ");
            Handler handler = handlers.get(words[0]);
            String value = "";
            if ( words.length > 1 )
                value = words[1];
            if( handler != null){
                handler.doCmd(value);
                if ( currentRoom.getDescription().equals( "卧室"))
                    break;
            }
//            if (words[0].equals("help")) {
//                game.printHelp();
//            } else if (words[0].equals("go")) {
//                game.goRoom(words[1]);
//            } else if (words[0].equals("bye")) {
//                break;
//            }
        }
        in.close();
    }

    public static void main(String[] args) {
        // write your code here

        Game game = new Game();
        game.printWelcome();
        game.play();

        System.out.println("恭喜回到卧室，可以睡觉啦！");

    }
}