package com.company;

/**
 * @description:
 * @author: HUAN丶
 * @date: Created in 2020/4/16 16:10
 * @version: ${VERSION}
 * @modified By:
 */
public class Handler {
    protected Game game;

    public Handler(Game game) {
        this.game = game;
    }

    public void doCmd(String word) {
    }

    public boolean isBye() {
        return false;
    }
}
