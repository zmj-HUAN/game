package com.company;

/**
 * @description:
 * @author: HUAN丶
 * @date: Created in 2020/4/16 16:23
 * @version: ${VERSION}
 * @modified By:
 */
public class HandlerBye extends Handler {
    public HandlerBye(Game game) {
        super(game);
    }

    @Override
    public boolean isBye() {
        return true;
    }
}
