package com.company;

/**
 * @description:
 * @author: HUAN丶
 * @date: Created in 2020/4/16 16:48
 * @version: ${VERSION}
 * @modified By:
 */
public class HandlerGo extends Handler{
    public HandlerGo(Game game) {
        super(game);
    }
    @Override
    public void doCmd(String word) {
        game.goRoom(word);
    }
}
