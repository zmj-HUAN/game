package com.company;

import java.util.HashMap;

/**
 * @description:
 * @author: HUAN丶
 * @date: Created in 2020/4/16 9:44
 * @version: ${VERSION}
 * @modified By:
 */
public class Room {
    public int hurt;
    private String description;
    private HashMap<String, Room> exits = new HashMap<String, Room>();


    public Room(String description) {
        this.description = description;
        this.hurt = 10;
    }

    public String getDescription() {
        return description;
    }

    public void setExit(String dir, Room room) {
        exits.put(dir, room);
    }

    @Override
    public String toString() {
        return description;
    }

    public String getExitDesc() {
        StringBuffer sb = new StringBuffer();
        for (String dir : exits.keySet()) {
            sb.append(dir);
            sb.append(' ');
        }
        return sb.toString();
    }

    public Room getExit(String direction) {
        return exits.get(direction);
    }
}